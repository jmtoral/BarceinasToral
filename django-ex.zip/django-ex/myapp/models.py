from django.db import models

# Create your models here.

STATES = (
['AGS', 'Aguascalientes'], ['BC', 'Baja California'], ['BCS', 'Baja California Sur'],
['CAM', 'Campeche'], ['COAH ', 'Coahuila de Zaragoza'], ['COL', 'Colima'],
['CHIS', 'Chiapas'], ['CHI', 'Chihuahua'], ['CDMX', 'Ciudad de Mexico'],
['DUR', 'Durango'], ['GTO', 'Guanajuato'], ['GRO', 'Guerrero'], ['HGO', 'Hidalgo'],
['JAL', 'Jalisco'], ['EDOMEX', 'Mexico'], ['MICH ', 'Michoacan de Ocampo'], ['MOR', 'Morelos'],
['NAY', 'Nayarit'], ['NL', 'Nuevo Leon'], ['OAX', 'Oaxaca'], ['PUE', 'Puebla'], ['QRO', 'Queretaro'],
['QROO', 'Quintana Roo'], ['SLP', 'San Luis Potosi'], ['SIN', 'Sinaloa'],
['SON', 'Sonora'], ['TAB', 'Tabasco'], ['TAM', 'Tamaulipas'], ['TLAX', 'Tlaxcala'],
['VER', 'Veracruz de Ignacio de la Llave'], ['YUC', 'Yucatan'], ['ZAC', 'Zacatecas']
   )


CURRENCY = (('EUR', "Euro"),
            ('GBP', "British Pound"),
            ("AUD", "Australian Dollar")
           )

STATES_DICT = dict(STATES)
CURRENCY_DICT = dict(CURRENCY)

class Input(models.Model):

    state = models.CharField(max_length=2, choices=STATES)
    address = models.CharField(max_length=50)

    currency = models.CharField(max_length=3, choices=CURRENCY)



COUNTIES = (
            ['AGS', 'Aguascalientes'], ['BC', 'Baja California'], ['BCS', 'Baja California Sur'],
            ['CAM', 'Campeche'], ['COAH ', 'Coahuila de Zaragoza'], ['COL', 'Colima'],
            ['CHIS', 'Chiapas'], ['CHI', 'Chihuahua'], ['CDMX', 'Ciudad de Mexico'], ['DUR', 'Durango'],
            ['GTO', 'Guanajuato'], ['GRO', 'Guerrero'], ['HGO', 'Hidalgo'], ['JAL', 'Jalisco'],
            ['EDOMEX', 'Mexico'], ['MICH ', 'Michoacan de Ocampo'], ['MOR', 'Morelos'],
            ['NAY', 'Nayarit'], ['NL', 'Nuevo Leon'], ['OAX', 'Oaxaca'], ['PUE', 'Puebla'],
            ['QRO', 'Queretaro'], ['QROO', 'Quintana Roo'], ['SLP', 'San Luis Potosi'],
            ['SIN', 'Sinaloa'], ['SON', 'Sonora'], ['TAB', 'Tabasco'],
            ['TAM', 'Tamaulipas'], ['TLAX', 'Tlaxcala'], ['VER', 'Veracruz de Ignacio de la Llave'],
            ['YUC', 'Yucatan'], ['ZAC', 'Zacatecas'],
           )


class Counties(models.Model):

  county = models.CharField(choices=COUNTIES, max_length=32)
